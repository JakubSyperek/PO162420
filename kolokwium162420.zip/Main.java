import java.util.Arrays;

public class Main {
    public static boolean dokladnosc (float x, float y, float k)
    {
        float ab = Math.abs(x-y);
        if(ab <= Math.pow(10, -k))
            return true;
        else
            return false;

    }

    public static int najblizszySasiad(int S){
        float sqrt = (float) Math.sqrt(S);
        int ss = (int) sqrt;
        if(sqrt - ss < 0.5){
            return ss;
        }else return ss+1;

    }

    public static int pierwiastek(int S, int n, double k){
        for(int i=1; i<=n; i++) {
            n = (int) ((i*(n-1) + S/Math.pow(i,(n-1))) / i);
            if((Math.abs((n-1) - n) <= Math.pow(10, -k))){
                return n;
            }
        }

        return 0;
    }

    public static int podciag(int[] tab){
        int maks = 0;
        int[] tab2 = new int[tab.length];
        for(int i=0;i<tab.length; i++){
            if(tab[i] <= maks)
            {
                maks = tab[i];
            }

        }
        for(int i=0;i<tab.length; i++){
            if(tab[i] < maks)
            {
                tab2[i] = tab[i];
            }
        }
        return tab2.length;
    }

    public static int podciag(int[] tab, int r){
        return 0;
    }

    public static int czyPalindrom(int n){
        return 0;
    }

    public static int palindromLiczbowy(int m){
        return 0;
    }


    public static void main(String[] args) {

        int[] arr;
        arr = new int[]{7, 6, 3, 4, 8, 2};

        System.out.println(dokladnosc(10,4,2));
        System.out.println(najblizszySasiad(22));
        System.out.println(pierwiastek(20, 2, 0.2));
        System.out.println(podciag(arr));
        System.out.println(podciag(arr, 2));


    }
}